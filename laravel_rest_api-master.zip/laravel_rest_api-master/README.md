<h3>Laravel REST API using Passport</h3>

<ol>
    <li>Clone the Project</li>
    <li>After Cloning, run <code>composer install</code></li>
    <li>create .env . match it into your database credentials</li>
    <li>Run <code>php artisan serve</code></li>
</ol>
